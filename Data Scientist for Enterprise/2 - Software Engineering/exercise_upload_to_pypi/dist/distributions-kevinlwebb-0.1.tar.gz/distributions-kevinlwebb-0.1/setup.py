from setuptools import setup

setup(name='distributions-kevinlwebb',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributions'],
      zip_safe=False)
